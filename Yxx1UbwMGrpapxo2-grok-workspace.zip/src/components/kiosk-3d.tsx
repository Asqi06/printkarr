import { useEffect, useRef } from "react";
import * as THREE from "three";
import { RoundedBoxGeometry } from "three/addons/geometries/RoundedBoxGeometry.js";

type Handle = {
  setProgress: (p: number) => void;
  setMouse: (nx: number, ny: number) => void;
};

function canvasTexture(
  w: number,
  h: number,
  draw: (ctx: CanvasRenderingContext2D, w: number, h: number) => void,
) {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const ctx = c.getContext("2d");
  if (!ctx) throw new Error("2d context missing");
  draw(ctx, w, h);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  tex.needsUpdate = true;
  return tex;
}

function qrTexture(seed: number) {
  return canvasTexture(256, 256, (ctx, w, h) => {
    ctx.fillStyle = "#F4F7FC";
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = "#071833";
    const cells = 21;
    const s = w / cells;
    const bit = (x: number, y: number) => {
      const n = Math.sin(x * 12.9898 + y * 78.233 + seed) * 43758.5453;
      return n - Math.floor(n) > 0.46;
    };
    const finder = (ox: number, oy: number) => {
      for (let y = 0; y < 7; y++) {
        for (let x = 0; x < 7; x++) {
          const edge = x === 0 || y === 0 || x === 6 || y === 6;
          const inner = x >= 2 && x <= 4 && y >= 2 && y <= 4;
          if (edge || inner) ctx.fillRect((ox + x) * s, (oy + y) * s, s + 0.5, s + 0.5);
        }
      }
    };
    finder(0, 0);
    finder(cells - 7, 0);
    finder(0, cells - 7);
    for (let y = 0; y < cells; y++) {
      for (let x = 0; x < cells; x++) {
        const inFinder =
          (x < 9 && y < 9) || (x > cells - 10 && y < 9) || (x < 9 && y > cells - 10);
        if (inFinder) continue;
        if (bit(x, y)) ctx.fillRect(x * s, y * s, s + 0.5, s + 0.5);
      }
    }
  });
}

function screenTexture() {
  return canvasTexture(1024, 640, (ctx, w, h) => {
    const g = ctx.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, "#0B1F4A");
    g.addColorStop(1, "#071833");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = "#1A5BFF";
    ctx.fillRect(0, 0, w, 8);
    ctx.font = "700 72px ui-sans-serif, system-ui, sans-serif";
    ctx.fillStyle = "#FFFFFF";
    ctx.fillText("Print", 80, 170);
    ctx.fillStyle = "#5B8CFF";
    ctx.fillText("Karr", 80 + ctx.measureText("Print").width, 170);
    ctx.font = "500 34px ui-sans-serif, system-ui, sans-serif";
    ctx.fillStyle = "#9BB0D0";
    ctx.fillText("Ready to print  ·  24/7", 80, 230);
    ctx.fillStyle = "#13284F";
    roundRect(ctx, 80, 300, w - 160, 88, 22);
    ctx.fill();
    ctx.fillStyle = "#1A5BFF";
    roundRect(ctx, 92, 312, 210, 64, 16);
    ctx.fill();
    ctx.fillStyle = "#FFFFFF";
    ctx.font = "600 28px ui-sans-serif, system-ui, sans-serif";
    ctx.fillText("ONLINE", 128, 354);
    ctx.fillStyle = "#8AA0C4";
    ctx.font = "500 26px ui-sans-serif, system-ui, sans-serif";
    ctx.fillText("Scan kiosk QR to start", 330, 354);
    ctx.fillStyle = "#1A5BFF";
    ctx.globalAlpha = 0.9;
    roundRect(ctx, 80, 430, w - 160, 110, 24);
    ctx.fill();
    ctx.globalAlpha = 1;
    ctx.fillStyle = "#FFFFFF";
    ctx.font = "600 36px ui-sans-serif, system-ui, sans-serif";
    ctx.fillText("Tap phone  ·  Print in 60s", 110, 498);
  });
}

function wrapTexture() {
  return canvasTexture(1024, 1024, (ctx, w, h) => {
    ctx.fillStyle = "#1A5BFF";
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = "#FFFFFF";
    ctx.font = "700 120px ui-sans-serif, system-ui, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("Print", w / 2 - 10, 430);
    ctx.fillStyle = "#D6E4FF";
    ctx.fillText("Karr", w / 2 - 10, 560);
    ctx.font = "600 36px ui-sans-serif, system-ui, sans-serif";
    ctx.fillStyle = "rgba(255,255,255,0.75)";
    ctx.fillText("INSTANT PRINT KIOSK", w / 2, 650);
  });
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function mat(color: string, extras: THREE.MeshPhysicalMaterialParameters = {}) {
  return new THREE.MeshPhysicalMaterial({
    color,
    roughness: 0.32,
    metalness: 0.08,
    clearcoat: 0.55,
    clearcoatRoughness: 0.28,
    ...extras,
  });
}

function buildKiosk(textures: {
  screen: THREE.Texture;
  wrap: THREE.Texture;
  qrA: THREE.Texture;
  qrB: THREE.Texture;
}) {
  const root = new THREE.Group();
  const white = mat("#EEF3FA");
  const ink = mat("#0C1C33");
  const blue = mat("#1A5BFF");
  const pale = mat("#D9E6FF");
  const darkGlass = mat("#070F1C", { roughness: 0.12, metalness: 0.2, transmission: 0, opacity: 1 });

  const body = new THREE.Mesh(new RoundedBoxGeometry(1.28, 3.42, 0.92, 6, 0.12), white);
  body.castShadow = true;
  body.receiveShadow = true;
  root.add(body);

  const wrap = new THREE.Mesh(
    new RoundedBoxGeometry(1.32, 1.18, 0.96, 4, 0.08),
    new THREE.MeshPhysicalMaterial({
      map: textures.wrap,
      roughness: 0.28,
      metalness: 0.06,
      clearcoat: 0.4,
    }),
  );
  wrap.position.y = -0.62;
  root.add(wrap);

  const left = new THREE.Mesh(new RoundedBoxGeometry(0.08, 3.2, 0.78, 2, 0.04), blue);
  left.position.set(-0.66, 0.02, 0.02);
  root.add(left);
  const right = left.clone();
  right.position.x = 0.66;
  root.add(right);

  const bezel = new THREE.Mesh(new RoundedBoxGeometry(1.08, 0.78, 0.1, 4, 0.05), ink);
  bezel.position.set(0, 1.22, 0.46);
  root.add(bezel);

  const screen = new THREE.Mesh(
    new THREE.PlaneGeometry(0.96, 0.66),
    new THREE.MeshBasicMaterial({ map: textures.screen }),
  );
  screen.position.set(0, 1.22, 0.515);
  root.add(screen);

  const cam = new THREE.Mesh(new THREE.CircleGeometry(0.028, 24), ink);
  cam.position.set(0, 1.58, 0.52);
  root.add(cam);
  const camDot = new THREE.Mesh(
    new THREE.CircleGeometry(0.012, 16),
    new THREE.MeshBasicMaterial({ color: "#1A5BFF" }),
  );
  camDot.position.set(0, 1.58, 0.522);
  root.add(camDot);

  const slot = new THREE.Mesh(new RoundedBoxGeometry(0.72, 0.08, 0.12, 2, 0.02), ink);
  slot.position.set(0, 0.12, 0.48);
  root.add(slot);

  const paper = new THREE.Mesh(new THREE.BoxGeometry(0.58, 0.01, 0.36), pale);
  paper.position.set(0, 0.12, 0.62);
  paper.rotation.x = -0.18;
  root.add(paper);

  const tray = new THREE.Mesh(new RoundedBoxGeometry(0.82, 0.06, 0.28, 2, 0.03), white);
  tray.position.set(0, -0.08, 0.54);
  root.add(tray);

  const qrMatA = new THREE.MeshBasicMaterial({ map: textures.qrA });
  const qrMatB = new THREE.MeshBasicMaterial({ map: textures.qrB });
  const qrA = new THREE.Mesh(new THREE.PlaneGeometry(0.32, 0.32), qrMatA);
  qrA.position.set(-0.28, -0.72, 0.49);
  root.add(qrA);
  const qrB = new THREE.Mesh(new THREE.PlaneGeometry(0.32, 0.32), qrMatB);
  qrB.position.set(0.28, -0.72, 0.49);
  root.add(qrB);

  const led = new THREE.Mesh(
    new THREE.SphereGeometry(0.03, 16, 16),
    new THREE.MeshStandardMaterial({
      color: "#3D7EFF",
      emissive: "#1A5BFF",
      emissiveIntensity: 1.4,
    }),
  );
  led.position.set(0.48, 0.42, 0.47);
  root.add(led);

  const mascot = buildMascot();
  mascot.position.set(0, 0.52, 0.5);
  mascot.scale.setScalar(0.92);
  root.add(mascot);

  for (const sx of [-0.42, 0.42]) {
    for (const sz of [-0.28, 0.28]) {
      const foot = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.08, 0.08, 16), ink);
      foot.position.set(sx, -1.78, sz);
      root.add(foot);
    }
  }

  const cap = new THREE.Mesh(new RoundedBoxGeometry(1.2, 0.08, 0.86, 3, 0.04), pale);
  cap.position.y = 1.74;
  root.add(cap);

  root.position.y = -0.12;
  root.traverse((obj) => {
    const mesh = obj as THREE.Mesh;
    if (mesh.isMesh) {
      mesh.castShadow = true;
      mesh.receiveShadow = true;
    }
  });
  return { root, paper, led, mascot };
}

function buildMascot() {
  const g = new THREE.Group();
  const blue = mat("#1A5BFF", { roughness: 0.4 });
  const white = mat("#F4F7FC", { roughness: 0.35 });
  const ink = mat("#071833");
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.22, 32, 32), blue);
  head.position.y = 0.08;
  g.add(head);
  const body = new THREE.Mesh(new THREE.SphereGeometry(0.16, 28, 28), blue);
  body.scale.set(1.15, 0.85, 0.9);
  body.position.y = -0.14;
  g.add(body);
  const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.055, 16, 16), white);
  eyeL.position.set(-0.07, 0.1, 0.18);
  const eyeR = eyeL.clone();
  eyeR.position.x = 0.07;
  g.add(eyeL, eyeR);
  const pupilL = new THREE.Mesh(new THREE.SphereGeometry(0.026, 12, 12), ink);
  pupilL.position.set(-0.07, 0.1, 0.225);
  const pupilR = pupilL.clone();
  pupilR.position.x = 0.07;
  g.add(pupilL, pupilR);
  const smile = new THREE.Mesh(
    new THREE.TorusGeometry(0.07, 0.012, 8, 16, Math.PI),
    ink,
  );
  smile.position.set(0, 0.02, 0.2);
  smile.rotation.set(Math.PI, 0, 0);
  g.add(smile);
  return g;
}

function mountScene(el: HTMLElement): Handle & { dispose: () => void } {
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(32, 1, 0.1, 40);
  camera.position.set(0, 0.22, 6.15);
  camera.lookAt(0, 0.1, 0);

  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "high-performance" });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.75));
  renderer.setClearColor(0x000000, 0);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFShadowMap;
  el.appendChild(renderer.domElement);
  renderer.domElement.style.position = "absolute";
  renderer.domElement.style.inset = "0";
  renderer.domElement.style.width = "100%";
  renderer.domElement.style.height = "100%";
  renderer.domElement.style.zIndex = "1";
  const fallback = el.querySelector("[data-kiosk-fallback]");
  if (fallback instanceof HTMLElement) fallback.style.display = "none";

  const hemi = new THREE.HemisphereLight(0xeef3ff, 0xb8c4d8, 0.95);
  scene.add(hemi);
  const key = new THREE.DirectionalLight(0xffffff, 1.55);
  key.position.set(3.2, 6.2, 4.4);
  key.castShadow = true;
  key.shadow.mapSize.set(1024, 1024);
  key.shadow.camera.near = 1;
  key.shadow.camera.far = 18;
  key.shadow.camera.left = -4;
  key.shadow.camera.right = 4;
  key.shadow.camera.top = 5;
  key.shadow.camera.bottom = -4;
  scene.add(key);
  const fill = new THREE.DirectionalLight(0x9ec0ff, 0.55);
  fill.position.set(-4.5, 2.2, 2.4);
  scene.add(fill);
  const rim = new THREE.DirectionalLight(0xffffff, 0.45);
  rim.position.set(0.4, 3.2, -5);
  scene.add(rim);

  const screen = screenTexture();
  const wrap = wrapTexture();
  const qrA = qrTexture(1.7);
  const qrB = qrTexture(4.2);
  const { root, paper, led, mascot } = buildKiosk({ screen, wrap, qrA, qrB });
  scene.add(root);

  const shadow = new THREE.Mesh(
    new THREE.CircleGeometry(1.35, 48),
    new THREE.MeshBasicMaterial({ color: "#0C1C33", transparent: true, opacity: 0.12 }),
  );
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = -1.86;
  scene.add(shadow);

  const progress = { value: 0 };
  const mouse = { x: 0, y: 0 };
  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  let raf = 0;
  let last = performance.now();
  let disposed = false;

  const resize = () => {
    const w = el.clientWidth || 1;
    const h = el.clientHeight || 1;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h, false);
    camera.position.z = w < 720 ? 8.4 : 6.15;
  };
  const ro = new ResizeObserver(resize);
  ro.observe(el);
  resize();

  const tick = (now: number) => {
    if (disposed) return;
    const dt = Math.min((now - last) / 1000, 0.1);
    last = now;
    const p = reduced ? 0.42 : progress.value;
    const turn = -0.55 + p * Math.PI * 1.85;
    const scale = 0.98 + Math.sin(p * Math.PI) * 0.28;
    const bob = reduced ? 0 : Math.sin(now * 0.0014) * 0.04;
    root.rotation.y = THREE.MathUtils.damp(root.rotation.y, turn + mouse.x * 0.28, 6, dt);
    root.rotation.x = THREE.MathUtils.damp(root.rotation.x, 0.08 + p * 0.12 + mouse.y * 0.12, 6, dt);
    const s = THREE.MathUtils.damp(root.scale.x, scale, 5, dt);
    root.scale.setScalar(s);
    root.position.y = -0.12 + bob;
    paper.position.z = 0.52 + p * 0.22;
    const ledMat = led.material as THREE.MeshStandardMaterial;
    ledMat.emissiveIntensity = 0.8 + Math.sin(now * 0.006) * 0.7;
    mascot.rotation.y = Math.sin(now * 0.0018) * 0.15;
    renderer.render(scene, camera);
    raf = requestAnimationFrame(tick);
  };
  raf = requestAnimationFrame(tick);

  return {
    setProgress: (p: number) => {
      progress.value = Math.min(1, Math.max(0, p));
    },
    setMouse: (nx: number, ny: number) => {
      mouse.x = nx;
      mouse.y = ny;
    },
    dispose: () => {
      disposed = true;
      cancelAnimationFrame(raf);
      ro.disconnect();
      renderer.dispose();
      scene.traverse((obj) => {
        const mesh = obj as THREE.Mesh;
        if (mesh.geometry) mesh.geometry.dispose();
        const m = mesh.material;
        if (Array.isArray(m)) m.forEach((x) => x.dispose());
        else if (m) m.dispose();
      });
      screen.dispose();
      wrap.dispose();
      qrA.dispose();
      qrB.dispose();
      if (renderer.domElement.parentElement === el) el.removeChild(renderer.domElement);
    },
  };
}

export function KioskStage({ className }: { className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const handle = useRef<Handle | null>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let scene: ReturnType<typeof mountScene> | null = null;
    try {
      scene = mountScene(el);
      handle.current = scene;
    } catch {
      handle.current = null;
    }

    const onScroll = () => {
      const hero = document.getElementById("hero-stage");
      if (!hero || !handle.current) return;
      const rect = hero.getBoundingClientRect();
      const span = Math.max(hero.offsetHeight - window.innerHeight, 1);
      const p = Math.min(1, Math.max(0, -rect.top / span));
      handle.current.setProgress(p);
    };
    const onMove = (e: PointerEvent) => {
      if (!handle.current) return;
      const nx = (e.clientX / window.innerWidth) * 2 - 1;
      const ny = (e.clientY / window.innerHeight) * 2 - 1;
      handle.current.setMouse(nx, -ny);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("pointermove", onMove, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("pointermove", onMove);
      scene?.dispose();
    };
  }, []);

  return (
    <div ref={ref} className={className} aria-hidden="true">
      <div data-kiosk-fallback className="pointer-events-none absolute inset-0 flex items-end justify-center pb-10 sm:items-center sm:pb-0">
        <div className="relative h-[58vh] w-[min(220px,46vw)] max-h-[520px]">
          <div className="absolute inset-x-[8%] top-0 h-[18%] rounded-t-[18px] bg-navy" />
          <div className="absolute inset-x-[12%] top-[3%] h-[12%] rounded-[10px] bg-primary" />
          <div className="absolute inset-0 top-[16%] rounded-[22px] bg-paper shadow-card ring-1 ring-line" />
          <div className="absolute inset-x-0 bottom-[18%] h-[32%] rounded-b-[18px] bg-primary" />
          <div className="absolute left-1/2 top-[38%] size-16 -translate-x-1/2 rounded-full bg-primary ring-4 ring-paper" />
        </div>
      </div>
    </div>
  );
}
